### Hexlet tests and linter status:
[![Actions Status](https://github.com/Gvozdinni/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/Gvozdinni/python-project-49/actions)

<a href="https://codeclimate.com/github/Gvozdinni/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/ab826fe5dfc40af0b666/maintainability" /></a>

<a href="https://asciinema.org/a/WEKZthGpXymwQgoLZa4er6SoP" target="_blank"><img src="https://asciinema.org/a/WEKZthGpXymwQgoLZa4er6SoP.svg" /></a>
<a href="https://asciinema.org/a/78xAL5F3yENv062X0ldVC3eRX" target="_blank"><img src="https://asciinema.org/a/78xAL5F3yENv062X0ldVC3eRX.svg" /></a>
<a href="https://asciinema.org/a/CNoEjVXsF7r0HTkfLKpqM61ZM" target="_blank"><img src="https://asciinema.org/a/CNoEjVXsF7r0HTkfLKpqM61ZM.svg" /></a>
<a href="https://asciinema.org/a/f3h7yYnNZqGycskk6OvDFVsDt" target="_blank"><img src="https://asciinema.org/a/f3h7yYnNZqGycskk6OvDFVsDt.svg" /></a>
<a href="https://asciinema.org/a/7Qq61j2kb2K5nk8Sf6VWjOwBU" target="_blank"><img src="https://asciinema.org/a/7Qq61j2kb2K5nk8Sf6VWjOwBU.svg" /></a>