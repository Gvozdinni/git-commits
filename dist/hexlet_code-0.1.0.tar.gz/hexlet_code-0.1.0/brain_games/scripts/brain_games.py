from brain_games.cli import *


def main():

    welcome_user()