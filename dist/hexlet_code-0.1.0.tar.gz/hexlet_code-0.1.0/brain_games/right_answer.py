def checkout_answer(user_answer):
    if user_answer == 'yes':
        return 'no'
    elif user_answer == 'no':
        return 'yes'