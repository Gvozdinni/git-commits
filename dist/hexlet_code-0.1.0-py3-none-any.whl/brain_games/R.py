def R(random_num, array):
    return random_num in array