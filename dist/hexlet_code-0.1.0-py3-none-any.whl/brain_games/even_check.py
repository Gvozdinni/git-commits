def even_check(random_num):
    if random_num % 2 == 0:
        answer = 'yes'
        return answer
    else:
        answer = 'no'
        return answer
